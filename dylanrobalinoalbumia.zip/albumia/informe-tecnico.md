# Informe técnico — Albumia

## Objetivo y decisiones
Albumia es un prototipo de galería personal para reunir fotos, vídeos y GIF en una biblioteca visual. La vista inicial muestra todos los elementos agrupados por fecha; la navegación lateral permite filtrar por tipo, favoritos y álbum. Se añadió búsqueda, ordenamiento, creación de álbumes, previsualización, vista de lista y cuadrícula, y selección múltiple de archivos.

La estructura utiliza HTML5 semántico (`header`, `nav`, `main`, `section`, `article`, `footer`), un único encabezado principal y jerarquía de títulos. Las imágenes tienen alternativas textuales y el formulario de creación de álbum incluye una etiqueta asociada. Los diálogos y mensajes de estado aportan contexto a las interacciones.

El CSS sigue enfoque mobile-first, centraliza colores y medidas en variables, emplea Grid para las tarjetas y Flexbox para barras y navegación, y mantiene imágenes fluidas. Las media queries a 760 px convierten la barra lateral en un menú desplegable y reducen columnas y controles; a 390 px ajustan márgenes y tipografía para pantallas estrechas. A 1100 px se reduce la cantidad de columnas y el espacio lateral; a 1500 px se aprovecha el ancho adicional. Se respeta `prefers-reduced-motion`.

JavaScript nativo implementa filtros por tipo/álbum/favoritos, búsqueda y ordenamiento, alta de álbumes, carga local de archivos, vista previa y cambio de cuadrícula/lista. No se incluyen dependencias JavaScript. La fuente decorativa puede recurrir a Google Fonts si hay conexión; el sistema tiene fuentes de respaldo.

## Pruebas realizadas
- Capturas de referencia en 390 px, 768 px y 1440 px.
- Verificación de navegación por teclado: enlace para saltar al contenido, enlaces de navegación, botones y controles de formulario.
- Foco visible para búsqueda y nombre del álbum; diálogos con cierre y mensajes de estado.
- Revisión de diseño a ancho móvil, tablet y escritorio, con cuadrícula adaptable y sin desbordamiento horizontal intencional.
- Revisión manual de etiquetas semánticas, `alt`, `label`, atributos ARIA básicos y estructura de encabezados.

## Mejoras pendientes y limitaciones
Este proyecto es un prototipo local: los archivos añadidos se guardan localmente en IndexedDB del navegador y no se sincronizan entre dispositivos. No hay cuentas, sincronización en la nube, eliminación individual ni gestión de permisos. El almacenamiento local puede borrarse al limpiar los datos del navegador. Para producción se recomienda integrar IndexedDB o un backend, autenticación, cifrado en tránsito, copias de seguridad, controles de cuota, pruebas automáticas de accesibilidad (axe/Lighthouse), pruebas con lectores de pantalla y validadores HTML/CSS. El contraste debe revisarse con herramientas automáticas y usuarios reales antes de publicar.


## Revisión visual: dirección editorial

Se sustituyó la estética de dashboard pastel por una composición de archivo fotográfico: fondo cálido neutro, tinta oscura y acento terracota; titulares serif de gran escala; navegación lateral más discreta; bordes finos en lugar de tarjetas omnipresentes; y una cuadrícula de imágenes grandes con proporciones alternadas. El icono original se conserva deliberadamente como sello de la aplicación. En móvil se reduce la decoración y se priorizan la lectura y el acceso a la galería.

### Recursos visuales de demostración
Se sustituyeron las miniaturas vectoriales genéricas por fotografías remotas de Unsplash y un GIF de demostración de Giphy. Se mantiene una alternativa local para errores de carga. Las imágenes remotas solo se usan como contenido de ejemplo; los archivos seleccionados por el usuario se guardan en IndexedDB del navegador y no se suben a servicios externos. Como mejora pendiente, conviene descargar y revisar las licencias de las imágenes definitivas si el proyecto se publica o se distribuye sin conexión.
