# Verificación para la entrega (Albumia)

Marca cada prueba solo después de realizarla en Opera GX.

- [ ] En 390 px, no hay desplazamiento horizontal; el menú lateral se abre y cierra.
- [ ] En 768 px, la galería y los controles se adaptan.
- [ ] En 1440 px, la galería aprovecha el ancho sin deformar las imágenes.
- [ ] Se puede recorrer la interfaz con Tab y ver el foco.
- [ ] Enter o Espacio abre una tarjeta seleccionada y Escape cierra la vista previa.
- [ ] Se puede crear un álbum; si se repite el nombre, aparece un aviso.
- [ ] Una foto subida continúa visible después de F5 (IndexedDB).
- [ ] Los favoritos y nombres de álbumes continúan después de F5 (localStorage).
- [ ] Se prueban búsqueda, filtros, ordenación y cambio de vista.
- [ ] Se prueba el sitio al 200 % de zoom y con animaciones reducidas.
- [ ] Se valida el HTML en https://validator.w3.org/nu/ y se corrigen los errores reportados.

Nota: las fotos de ejemplo remotas requieren internet. Los archivos subidos permanecen en este navegador.
