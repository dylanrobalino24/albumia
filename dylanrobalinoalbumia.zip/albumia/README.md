# Albumia — galería personal

Sitio web responsive para una biblioteca personal de fotos, vídeos y GIF. Proyecto académico realizado con HTML5 semántico, CSS mobile-first y JavaScript nativo, sin frameworks.

## Cómo abrirlo
1. Descarga y descomprime `albumia-entrega.zip`.
2. Recomendado: abre la carpeta con VS Code Live Server o cualquier servidor estático local para que el almacenamiento IndexedDB tenga un origen estable. No requiere instalación de dependencias.
3. Pulsa **Subir archivos** para probar con imágenes, GIF y vídeos locales.

## Funciones
- Navegación lateral: todos los elementos, fotos, vídeos, GIF y favoritos.
- Agrupación por fecha, orden cronológico o alfabético y búsqueda por nombre/álbum.
- Crear álbumes y filtrar la biblioteca por álbum.
- Vista de cuadrícula o lista, previsualización y favoritos.
- Menú lateral adaptable para móviles, foco visible y atajo Ctrl/Cmd + K para buscar.
- Icono original de cámara dibujada intencionalmente imperfecta en `assets/icono.svg`.

## Alcance importante
Es un prototipo frontend local, no un servicio de nube. Los elementos de ejemplo son ilustraciones SVG; los archivos elegidos se muestran en la sesión actual del navegador y no se cargan a un servidor ni se guardan de forma permanente. Si se cierra o recarga la página, se pierden los archivos añadidos. Para una versión real multi-dispositivo se necesitaría backend, almacenamiento, autenticación, copias de seguridad y controles de privacidad.

## Estructura
- `index.html`: estructura semántica y componentes.
- `styles.css`: diseño responsive, variables, Flexbox/Grid y media queries.
- `app.js`: filtros, búsqueda, favoritos, álbumes, subida local y previsualización.
- `assets/`: icono y miniaturas ilustrativas.
- `informe-tecnico.md`: decisiones, pruebas y mejoras pendientes.
- `capturas/`: capturas de escritorio, tablet y móvil.


## Dirección visual del rediseño

La interfaz utiliza una paleta de papel, tinta y terracota; serif editorial para titulares y nombres de archivo; separadores finos en vez de tarjetas repetidas; y proporciones de imagen variadas para que la galería sea el centro visual. El icono original se conserva como elemento de identidad. Las adaptaciones responsive mantienen la navegación y reorganizan la galería para móvil y tablet.

### Fotografías de demostración
Las miniaturas de ejemplo utilizan fotografías remotas de Unsplash y un GIF remoto de Giphy para que la galería se vea más realista. Necesitas conexión a internet para ver esos recursos de muestra. Si una imagen remota no carga, la interfaz usa una ilustración local de respaldo. Los archivos que subas desde tu dispositivo se mantienen en el almacenamiento local del navegador y no se envían a esos servicios.

## Organización del código

- `index.html`: estructura y elementos de la interfaz.
- `styles.css`: diseño adaptable y estilos.
- `app.js`: datos de ejemplo, galería, filtros, eventos y almacenamiento local.

El JavaScript está dividido en funciones por tarea y no requiere librerías externas.
Las fotos de ejemplo se cargan desde internet; los archivos que subas se guardan
localmente mediante IndexedDB. No se utiliza un archivo JSON independiente.

## Criterios de evaluación

La galería usa columnas progresivas desde móvil (2) hasta escritorio (4). Se añadieron controles accesibles, validación de nombres de álbum y persistencia de favoritos/álbumes en localStorage. Las fotos del usuario siguen guardándose en IndexedDB. Antes de entregar, realiza las comprobaciones de `PRUEBAS.md`; no se presentan como pruebas realizadas automáticamente.
