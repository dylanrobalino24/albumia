'use strict';

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

const samples = [
  { id: 's1', name: 'Tarde entre flores.jpg', date: '2026-10-14', type: 'photo', album: 'Inspiración', src: 'https://images.unsplash.com/photo-1490750967868-88aa4486c946?auto=format&fit=crop&w=1200&q=85', size: '1.2 MB' },
  { id: 's2', name: 'Un día en la costa.jpg', date: '2026-10-14', type: 'photo', album: 'Viajes', src: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?auto=format&fit=crop&w=1200&q=85', size: '2.4 MB' },
  { id: 's3', name: 'Luz de domingo.jpg', date: '2026-10-14', type: 'photo', album: 'Familia', src: 'https://images.unsplash.com/photo-1470252649378-9c29740c9fa8?auto=format&fit=crop&w=1200&q=85', size: '980 KB' },
  { id: 's4', name: 'Pequeños detalles.gif', date: '2026-10-12', type: 'gif', album: 'Inspiración', src: 'https://media.giphy.com/media/JIX9t2j0ZTN9S/giphy.gif', size: '640 KB' },
  { id: 's5', name: 'Ruta de montaña.mp4', date: '2026-10-12', type: 'video', album: 'Viajes', src: 'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4', poster: 'https://images.unsplash.com/photo-1501785888041-af3ef285b470?auto=format&fit=crop&w=1200&q=85', size: '18 MB' },
  { id: 's6', name: 'Nuestro lugar.jpg', date: '2026-10-09', type: 'photo', album: 'Familia', src: 'https://images.unsplash.com/photo-1511895426328-dc8714191300?auto=format&fit=crop&w=1200&q=85', size: '1.8 MB' },
  { id: 's7', name: 'Café y lluvia.jpg', date: '2026-10-09', type: 'photo', album: 'Inspiración', src: 'https://images.unsplash.com/photo-1445116572660-236099ec97a0?auto=format&fit=crop&w=1200&q=85', size: '1.1 MB' },
  { id: 's8', name: 'La última escapada.jpg', date: '2026-10-03', type: 'photo', album: 'Viajes', src: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?auto=format&fit=crop&w=1200&q=85', size: '2.1 MB' }
];

const initialAlbums = ['Viajes', 'Familia', 'Inspiración'];
let items = samples.map(item => ({ ...item }));
let albums = [...initialAlbums];
let view = 'all';
let selectedAlbum = '';
let layout = 'grid';
let toastTimer;
let db = null;
const SETTINGS_KEY = 'albumia-settings';


function escapeHTML(value) {
  const entities = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  return String(value).replace(/[&<>"']/g, char => entities[char]);
}

function niceDate(date) {
  return new Date(`${date}T12:00:00`).toLocaleDateString('es-EC', {
    day: 'numeric', month: 'long', year: 'numeric'
  });
}

function notify(message) {
  const toast = $('#toast');
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 2800);
}

function openDB() {
  return new Promise(resolve => {
    if (!('indexedDB' in window)) return resolve(null);

    const request = indexedDB.open('albumia-library', 1);
    request.onupgradeneeded = () => {
      if (!request.result.objectStoreNames.contains('uploads')) {
        request.result.createObjectStore('uploads', { keyPath: 'id' });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => resolve(null);
  });
}

function dbRequest(mode, action, value) {
  return new Promise(resolve => {
    if (!db) return resolve(null);

    try {
      const store = db.transaction('uploads', mode).objectStore('uploads');
      const request = action === 'getAll' ? store.getAll()
        : action === 'put' ? store.put(value) : store.clear();
      request.onsuccess = () => resolve(request.result ?? true);
      request.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}

function saveSettings() {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify({ albums, favorites: items.filter(item => item.favorite).map(item => item.id) }));
  } catch {
    notify('No se pudieron guardar las preferencias del navegador.');
  }
}

function loadSettings() {
  try {
    return JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}');
  } catch {
    return {};
  }
}

function visibleItems() {
  let list = [...items];
  const search = $('#searchInput').value.trim().toLocaleLowerCase('es');
  const sort = $('#sortSelect').value;

  if (['photo', 'video', 'gif'].includes(view)) {
    list = list.filter(item => item.type === view);
  }
  if (view === 'favorites') list = list.filter(item => item.favorite);
  if (selectedAlbum) list = list.filter(item => item.album === selectedAlbum);
  if (search) {
    list = list.filter(item =>
      item.name.toLocaleLowerCase('es').includes(search) ||
      (item.album || '').toLocaleLowerCase('es').includes(search)
    );
  }

  list.sort((a, b) => {
    if (sort === 'oldest') return a.date.localeCompare(b.date);
    if (sort === 'name') return a.name.localeCompare(b.name, 'es');
    return b.date.localeCompare(a.date);
  });
  return list;
}

function makeCard(item) {
  const card = document.createElement('article');
  const fallback = item.type === 'gif' ? 'assets/demo-gif.svg'
    : item.type === 'video' ? 'assets/demo-mountain.svg' : 'assets/demo-sun.svg';
  const label = { photo: 'FOTO', video: 'VÍDEO', gif: 'GIF' }[item.type];

  card.className = 'photo-card';
  card.tabIndex = 0;
  card.setAttribute('role', 'button');
  card.setAttribute('aria-label', `${item.name}, abrir vista previa`);

  const visual = item.type === 'video'
    ? `<video class="thumb video-thumb" src="${escapeHTML(item.src)}" poster="${escapeHTML(item.poster || '')}" muted playsinline preload="metadata" aria-label="Vista previa de ${escapeHTML(item.name)}"></video><span class="video-play" aria-hidden="true">Reproducir</span>`
    : `<img class="thumb" src="${escapeHTML(item.src)}" alt="Vista previa de ${escapeHTML(item.name)}" loading="lazy" referrerpolicy="no-referrer">`;

  card.innerHTML = `
    ${visual}
    <span class="type-chip">${label}</span>
    <div class="card-info">
      <div>
        <span class="card-name">${escapeHTML(item.name)}</span>
        <span class="card-meta">${escapeHTML(item.size || 'Archivo local')} · ${escapeHTML(item.album || 'Sin álbum')}</span>
      </div>
      <button class="favorite-button" type="button" aria-label="${item.favorite ? 'Quitar de' : 'Añadir a'} favoritos" aria-pressed="${!!item.favorite}">${item.favorite ? 'Quitar' : 'Guardar'}</button>
    </div>`;

  const thumb = $('.thumb', card);
  thumb.addEventListener('error', () => {
    if (thumb.dataset.fallbackApplied) return;
    thumb.dataset.fallbackApplied = 'true';
    if (thumb.tagName === 'VIDEO') {
      thumb.poster = fallback;
      thumb.removeAttribute('src');
      thumb.load();
    } else {
      thumb.src = fallback;
    }
  });

  if (thumb.tagName === 'VIDEO') {
    thumb.addEventListener('loadedmetadata', () => {
      if (!item.poster && thumb.duration > 0) thumb.currentTime = Math.min(0.1, thumb.duration / 2);
    }, { once: true });
  }

  card.addEventListener('click', event => {
    if (!event.target.closest('.favorite-button')) openPreview(item);
  });
  card.addEventListener('keydown', event => {
    if ((event.key === 'Enter' || event.key === ' ') && event.target === card) {
      event.preventDefault();
      openPreview(item);
    }
  });
  $('.favorite-button', card).addEventListener('click', event => {
    event.stopPropagation();
    item.favorite = !item.favorite;
    saveSettings();
    render();
    notify(item.favorite ? 'Añadido a favoritos' : 'Eliminado de favoritos');
  });
  return card;
}

function updateNav() {
  $$('.nav-link[data-view]').forEach(link => {
    link.classList.toggle('active', !selectedAlbum && link.dataset.view === view);
  });

  $('#albumList').innerHTML = '';
  albums.forEach((album, index) => {
    const link = document.createElement('a');
    link.href = '#contenido';
    link.className = 'nav-link' + (selectedAlbum === album ? ' active' : '');
    link.dataset.album = album;
    link.innerHTML = `<span class="album-dot ${['coral', 'lilac', 'mint'][index % 3]}"></span>${escapeHTML(album)}`;
    link.addEventListener('click', event => {
      event.preventDefault();
      selectedAlbum = album;
      view = 'all';
      render();
      closeMobileMenu();
    });
    $('#albumList').appendChild(link);
  });
}

function render() {
  const list = visibleItems();
  const gallery = $('#gallery');
  const titles = { all: 'Todas las fotos', photo: 'Fotos', video: 'Vídeos', gif: 'GIF animados', favorites: 'Favoritos' };
  const title = selectedAlbum || titles[view] || titles.all;

  gallery.innerHTML = '';
  gallery.hidden = list.length === 0;
  $('#emptyState').hidden = list.length > 0;
  $('#currentView').textContent = title;
  $('#galleryTitle').innerHTML = `${escapeHTML(title)} <span id="resultCount">${list.length}</span>`;
  $('#galleryEyebrow').textContent = selectedAlbum ? 'TU ÁLBUM' : view === 'favorites' ? 'TUS FAVORITOS' : 'TU COLECCIÓN';
  $('#allCount').textContent = items.length;
  $('#photoStat').textContent = items.filter(item => item.type === 'photo').length;
  $('#videoStat').textContent = items.filter(item => item.type === 'video').length;
  $('#gifStat').textContent = items.filter(item => item.type === 'gif').length;
  $('#albumStat').textContent = albums.length;

  const groups = new Map();
  list.forEach(item => {
    if (!groups.has(item.date)) groups.set(item.date, []);
    groups.get(item.date).push(item);
  });

  groups.forEach((group, date) => {
    const section = document.createElement('section');
    section.className = 'date-group';
    section.innerHTML = `<div class="date-heading"><h3>${escapeHTML(niceDate(date))}</h3><span>${group.length} ${group.length === 1 ? 'elemento' : 'elementos'}</span></div><div class="photo-grid ${layout === 'list' ? 'list-layout' : ''}"></div>`;
    const grid = $('.photo-grid', section);
    group.forEach(item => grid.appendChild(makeCard(item)));
    gallery.appendChild(section);
  });
  updateNav();
}

function openPreview(item) {
  const host = $('#previewContent');
  host.innerHTML = '';
  let media;

  if (item.type === 'video') {
    media = document.createElement('video');
    media.src = item.src;
    if (item.poster) media.poster = item.poster;
    media.controls = true;
    media.autoplay = true;
    media.playsInline = true;
  } else {
    media = document.createElement('img');
    media.src = item.src;
    media.alt = item.name;
  }

  host.appendChild(media);
  $('#previewCaption').textContent = `${item.name} · ${niceDate(item.date)}${item.album ? ' · ' + item.album : ''}`;
  $('#previewDialog').showModal();
  $('#closePreview').focus();
}

function closePreview() {
  $('#previewDialog').close();
  $('#previewContent').innerHTML = '';
}

async function addFiles(files) {
  let added = 0;
  for (const file of [...files]) {
    const type = file.type.startsWith('video/') ? 'video'
      : file.type === 'image/gif' ? 'gif'
      : file.type.startsWith('image/') ? 'photo' : null;
    if (!type) continue;

    const id = `u${Date.now()}${Math.random()}`;
    const date = new Date(file.lastModified || Date.now()).toISOString().slice(0, 10);
    const album = selectedAlbum || '';
    const size = file.size < 1048576
      ? `${Math.max(1, Math.round(file.size / 1024))} KB`
      : `${(file.size / 1048576).toFixed(1)} MB`;
    const src = URL.createObjectURL(file);

    items.unshift({ id, name: file.name, date, type, album, src, file: true, size });
    const stored = await dbRequest('readwrite', 'put', { id, name: file.name, date, type, album, size, blob: file });
    if (!stored) {
      URL.revokeObjectURL(src);
      items = items.filter(item => item.id !== id);
      notify('No se pudo guardar un archivo. Revisa el espacio disponible y los permisos del navegador.');
      continue;
    }
    added++;
  }

  if (added) {
    view = 'all';
    selectedAlbum = '';
    render();
    notify(`${added} archivo${added === 1 ? '' : 's'} guardado${added === 1 ? '' : 's'} en este navegador.`);
  } else if (files.length) {
    notify('Selecciona imágenes, GIF o vídeos compatibles.');
  }
  $('#fileInput').value = '';
}

function closeMobileMenu() {
  $('#sidebar').classList.remove('open');
  $('#menuToggle').setAttribute('aria-expanded', 'false');
}

function setLayout(next) {
  layout = next;
  $('#gridView').classList.toggle('selected', next === 'grid');
  $('#listView').classList.toggle('selected', next === 'list');
  $('#gridView').setAttribute('aria-pressed', String(next === 'grid'));
  $('#listView').setAttribute('aria-pressed', String(next === 'list'));
  render();
}

function initEvents() {
  $$('.nav-link[data-view]').forEach(link => link.addEventListener('click', event => {
    event.preventDefault();
    view = link.dataset.view;
    selectedAlbum = '';
    render();
    closeMobileMenu();
  }));

  ['#uploadTrigger', '#topUpload', '#emptyUpload'].forEach(selector => {
    $(selector).addEventListener('click', () => $('#fileInput').click());
  });
  $('#fileInput').addEventListener('change', event => addFiles(event.target.files));
  $('#searchInput').addEventListener('input', render);
  $('#sortSelect').addEventListener('change', render);
  $('#gridView').addEventListener('click', () => setLayout('grid'));
  $('#listView').addEventListener('click', () => setLayout('list'));

  $('#newAlbum').addEventListener('click', () => {
    $('#albumName').value = '';
    $('#albumDialog').showModal();
    $('#albumName').focus();
  });
  $('#albumName').addEventListener('input', () => $('#albumName').setCustomValidity(''));
  $('#albumForm').addEventListener('submit', event => {
    event.preventDefault();
    const name = $('#albumName').value.trim();
    if (!name) { $('#albumName').reportValidity(); return; }
    if (albums.some(album => album.toLocaleLowerCase() === name.toLocaleLowerCase())) {
      $('#albumName').setCustomValidity('Ya existe un álbum con ese nombre.');
      $('#albumName').reportValidity();
      return;
    }
    albums.push(name);
    saveSettings();
    selectedAlbum = name;
    view = 'all';
    $('#albumDialog').close();
    render();
    notify(`Álbum «${name}» creado.`);
  });

  $('#closePreview').addEventListener('click', closePreview);
  $('#previewDialog').addEventListener('click', event => {
    if (event.target === $('#previewDialog')) closePreview();
  });
  $('#previewDialog').addEventListener('close', () => {
    $('#previewContent').innerHTML = '';
  });
  $('#menuToggle').addEventListener('click', () => {
    const open = $('#sidebar').classList.toggle('open');
    $('#menuToggle').setAttribute('aria-expanded', String(open));
  });
  $('#helpButton').addEventListener('click', () => {
    notify('Los archivos se guardan en este navegador, sin subirlos a un servidor.');
  });
  $('#clearDemo').addEventListener('click', async () => {
    items.filter(item => item.file && item.src.startsWith('blob:'))
      .forEach(item => URL.revokeObjectURL(item.src));
    await dbRequest('readwrite', 'clear');
    items = samples.map(item => ({ ...item }));
    albums = [...initialAlbums];
    saveSettings();
    view = 'all';
    selectedAlbum = '';
    $('#searchInput').value = '';
    render();
    notify('Archivos añadidos eliminados y ejemplos restaurados.');
  });
  document.addEventListener('keydown', event => {
    if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
      event.preventDefault();
      $('#searchInput').focus();
    }
    if (event.key === 'Escape') closeMobileMenu();
  });
}

async function init() {
  initEvents();
  db = await openDB();
  const saved = await dbRequest('readonly', 'getAll');
  if (saved?.length) {
    saved.forEach(record => {
      const src = URL.createObjectURL(record.blob);
      items.unshift({ ...record, src, file: true });
    });
    $('#storageLabel').textContent = 'Guardado en este navegador';
  }
  const settings = loadSettings();
  if (Array.isArray(settings.albums)) {
    albums = [...new Set([...initialAlbums, ...settings.albums.filter(name => typeof name === 'string' && name.trim())])];
  }
  if (Array.isArray(settings.favorites)) {
    items.forEach(item => { item.favorite = settings.favorites.includes(item.id); });
  }
  render();
}

init();
